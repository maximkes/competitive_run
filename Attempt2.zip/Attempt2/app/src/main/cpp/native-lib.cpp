#include <jni.h>
#include <string>

char* DashaFunction (int a, int b) {
    return ("Hello from function Dasha");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_attempt2_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = DashaFunction(1,2);//"Hello from C++ to Android App Developers";
    return env->NewStringUTF(hello.c_str());
}